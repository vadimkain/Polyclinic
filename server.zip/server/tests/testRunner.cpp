#include <gtest/gtest.h>

TEST(MyTestSuite, TestName) {
    EXPECT_EQ(2 + 2, 4);
}