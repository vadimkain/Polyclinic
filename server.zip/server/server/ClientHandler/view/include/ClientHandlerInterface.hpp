#ifndef POLYCLINIC_SERVER_SERVER_CLIENTHANDLER_VIEW_CLIENTHANDLERINTERFACE_HPP
#define POLYCLINIC_SERVER_SERVER_CLIENTHANDLER_VIEW_CLIENTHANDLERINTERFACE_HPP

#include "IClientHandlerInterface.hpp"

namespace server::client_handler::view {

class ClientHandlerInterface : public IClientHandlerInterface {

};

}   // !server::client_handler::view;

#endif  // !POLYCLINIC_SERVER_SERVER_CLIENTHANDLER_VIEW_CLIENTHANDLERINTERFACE_HPP;